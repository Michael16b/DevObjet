
rootProject.name = "tp10-main"

