package iut.collections

interface Collection<E> {
    fun estVide() : Boolean
    fun taille() : Int
}